package com.cribbstechnologies.clients.mandrill.model.response.templates;

import com.cribbstechnologies.clients.mandrill.model.response.BaseMandrillAnonymousListResponse;

public class TemplateListResponse extends BaseMandrillAnonymousListResponse<TemplateResponse> {

}
