package com.cribbstechnologies.clients.mandrill.model.response.urls;

public class TimeUrlResponse extends BaseUrlResponse {

	String time;

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}
	
}
