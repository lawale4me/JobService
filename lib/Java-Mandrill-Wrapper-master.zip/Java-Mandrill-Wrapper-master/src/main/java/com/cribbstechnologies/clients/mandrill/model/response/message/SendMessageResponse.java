package com.cribbstechnologies.clients.mandrill.model.response.message;

import com.cribbstechnologies.clients.mandrill.model.response.BaseMandrillAnonymousListResponse;

public class SendMessageResponse extends BaseMandrillAnonymousListResponse<MessageResponse> {

}
