package com.cribbstechnologies.clients.mandrill.model.response.urls;

import com.cribbstechnologies.clients.mandrill.model.response.BaseMandrillAnonymousListResponse;

public class UrlTimeResponse extends BaseMandrillAnonymousListResponse<TimeUrlResponse> {

}
