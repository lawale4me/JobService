package com.cribbstechnologies.clients.mandrill.model.response.users;

import com.cribbstechnologies.clients.mandrill.model.response.BaseMandrillAnonymousListResponse;

public class UsersSendersResponse extends BaseMandrillAnonymousListResponse<MandrillSender> {

}
