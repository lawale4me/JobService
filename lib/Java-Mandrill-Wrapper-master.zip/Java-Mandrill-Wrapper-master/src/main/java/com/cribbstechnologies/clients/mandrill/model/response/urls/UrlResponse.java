package com.cribbstechnologies.clients.mandrill.model.response.urls;

public class UrlResponse extends BaseUrlResponse {

	String url;
	String time;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}
	
}
