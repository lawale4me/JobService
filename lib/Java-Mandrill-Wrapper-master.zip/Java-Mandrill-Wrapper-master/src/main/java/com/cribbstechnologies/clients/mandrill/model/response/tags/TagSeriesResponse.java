package com.cribbstechnologies.clients.mandrill.model.response.tags;

import com.cribbstechnologies.clients.mandrill.model.response.BaseMandrillAnonymousListResponse;

public class TagSeriesResponse extends BaseMandrillAnonymousListResponse<TagWithTime> {

}
