package com.cribbstechnologies.clients.mandrill.model.response.tags;

public class TagWithTime extends BaseTag {

	String time;

	public String getTime() {
		return time;
	}
	
	public void setTime(String time) {
		this.time = time;
	}
	
}
