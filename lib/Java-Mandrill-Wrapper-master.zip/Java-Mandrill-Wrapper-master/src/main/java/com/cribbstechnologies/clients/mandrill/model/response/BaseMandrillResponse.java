package com.cribbstechnologies.clients.mandrill.model.response;

public class BaseMandrillResponse {

}
