package com.cribbstechnologies.clients.mandrill.model;

public class MandrillHtmlMessage extends MandrillMessage {

	private String html;

	public String getHtml() {
		return html;
	}

	public void setHtml(String html) {
		this.html = html;
	}
	
}
